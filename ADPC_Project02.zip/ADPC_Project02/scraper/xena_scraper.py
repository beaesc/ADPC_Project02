from playwright.sync_api import sync_playwright
import requests
from urllib.parse import urljoin
from storage.minio_client import upload_to_minio 
import gzip
import os

# Xena Browser URL
XENA_HUB = "https://xenabrowser.net/datapages/?hub=https://tcga.xenahubs.net:443"
TEMP_DIR = "/tmp"  # Temporary directory for file storage

def get_cancer_cohorts():
    """Retrieve all TCGA cancer cohorts using Playwright."""
    print("Fetching TCGA cancer cohorts from Xena Browser...")

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(XENA_HUB, wait_until='networkidle')

        page.wait_for_timeout(5000)  # Wait for elements to load
        page.wait_for_selector("ul a", timeout=10000)

        links = page.locator("ul a").all()
        cancer_cohorts = []

        for link in links:
            href = link.get_attribute('href')
            if href and href.startswith('?cohort'):
                cohort_name = link.inner_text().strip()
                cohort_url = urljoin(XENA_HUB, href)
                print(f"Found cohort: {cohort_name}")
                cancer_cohorts.append((cohort_name, cohort_url))

        browser.close()

    print(f"Total cohorts found: {len(cancer_cohorts)}\n")
    return cancer_cohorts

def process_and_upload_tsv():
    """Find and directly upload gene expression TSV files to MiniO."""
    cohorts = get_cancer_cohorts()
    if not cohorts:
        print("No cohorts found!")
        return

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()

        for name, url in cohorts:
            print(f"Checking cohort: {name}")
            page.goto(url, wait_until='networkidle')

            try:
                dataset_link = page.wait_for_selector("a:text('IlluminaHiSeq pancan normalized')", timeout=10000)
                relative_url = dataset_link.get_attribute("href")
                dataset_url = urljoin(XENA_HUB, relative_url)
                print(f"Found dataset link for {name}")
                page.goto(dataset_url, wait_until='networkidle')
            except Exception as e:
                print(f"Dataset link not found for {name}: {e}")
                continue

            try:
                download_link = page.wait_for_selector("a[href*='amazonaws.com/download']", timeout=10000)
                file_url = download_link.get_attribute("href")

                print(f"Downloading {name}.tsv.gz from {file_url}")

                response = requests.get(file_url, stream=True)
                response.raise_for_status()

                # Temporary file paths
                gz_temp_path = os.path.join(TEMP_DIR, f"{name}.tsv.gz")
                tsv_temp_path = os.path.join(TEMP_DIR, f"{name}.tsv")

                # Save the compressed `.gz` file temporarily
                with open(gz_temp_path, "wb") as gz_file:
                    for chunk in response.iter_content(chunk_size=8192):
                        gz_file.write(chunk)

                print(f"Saved compressed file: {gz_temp_path}")

                # Decompress the `.gz` file and save as `.tsv`
                with gzip.open(gz_temp_path, "rb") as gz_file, open(tsv_temp_path, "wb") as tsv_file:
                    tsv_file.write(gz_file.read())

                print(f"Decompressed and saved TSV file: {tsv_temp_path}")

                # Upload the TSV file to MiniO
                upload_to_minio(tsv_temp_path, f"{name}.tsv")

                # Cleanup temporary files
                os.remove(gz_temp_path)
                os.remove(tsv_temp_path)
                print(f"Deleted temporary files for {name}\n")

            except Exception as e:
                print(f"Error processing {name}: {e}\n")
                continue

        browser.close()

if __name__ == "__main__":
    print("Starting scraper...")
    process_and_upload_tsv()
    print("Scraper finished.")
