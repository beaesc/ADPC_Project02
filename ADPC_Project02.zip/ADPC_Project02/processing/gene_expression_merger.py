import pandas as pd

def merge_with_clinical_data(gene_expression_df, clinical_data_path):
    """Merge gene expression data with clinical survival data."""
    
    # Load clinical survival data
    clinical_df = pd.read_csv(clinical_data_path, sep='\t', dtype=str)

    # Debugging: Show column names
    print(f"Clinical Data Columns: {clinical_df.columns.tolist()}")
    print(f"Gene Expression Data Columns: {gene_expression_df.columns.tolist()}")

    # Ensure correct column names
    if 'bcr_patient_barcode' not in clinical_df.columns:
        print("Error: 'bcr_patient_barcode' column missing in clinical data!")
        return None

    # Normalize patient IDs to match
    clinical_df['bcr_patient_barcode'] = clinical_df['bcr_patient_barcode'].str.strip().str.upper()
    gene_expression_df['bcr_patient_barcode'] = (
        gene_expression_df['bcr_patient_barcode'].str.strip().str.upper().str[:12]  # ✅ Remove `-03`
    )

    # Debugging: Show barcode values before merging
    print("Sample bcr_patient_barcode values from Clinical Data:")
    print(clinical_df['bcr_patient_barcode'].head())

    print("Sample bcr_patient_barcode values from Gene Expression Data (after fixing):")
    print(gene_expression_df['bcr_patient_barcode'].head())

    # Perform merging
    merged_df = pd.merge(gene_expression_df, clinical_df, on="bcr_patient_barcode", how="inner")

    # Debugging: Show result after merging
    print(f"Merged Data Shape: {merged_df.shape}")

    return merged_df
