import pandas as pd
import chardet  # Install via: pip install chardet
from storage.minio_client import minio_client, BUCKET_NAME

# List of genes in the cGAS-STING pathway
CGAS_STING_GENES = {
    "C6orf150", "CCL5", "CXCL10", "TMEM173", "CXCL9", "CXCL11", 
    "NFKB1", "IKBKE", "IRF3", "TREX1", "ATM", "IL6", "IL8"
}

def list_tsv_files():
    """List all TSV files stored in MiniO."""
    print("Listing TSV files in MiniO bucket...")
    objects = minio_client.list_objects(BUCKET_NAME, recursive=True)
    tsv_files = [obj.object_name for obj in objects if obj.object_name.endswith(".tsv")]
    print(f"Found {len(tsv_files)} TSV files.")
    return tsv_files

def download_tsv(file_name, local_path):
    """Download a TSV file from MiniO."""
    print(f"Downloading {file_name} from MiniO...")
    minio_client.fget_object(BUCKET_NAME, file_name, local_path)
    print(f"Downloaded {file_name} to {local_path}")

def detect_encoding(file_path):
    """Detect file encoding to avoid UnicodeDecodeError."""
    print(f"Detecting encoding for {file_path}...")
    with open(file_path, "rb") as f:
        raw_data = f.read(100000)  # Read first 100 KB
    result = chardet.detect(raw_data)
    encoding = result['encoding']
    print(f"Detected encoding for {file_path}: {encoding}")
    return encoding

def process_tsv(file_path, cancer_cohort):
    """Read and transform gene expression data from a TSV file."""
    print(f"Processing file: {file_path}...")
    
    encoding = detect_encoding(file_path)
    if encoding is None:
        print(f"Skipping {file_path} due to unknown encoding.")
        return None

    try:
        df = (pd.read_csv(file_path, sep='\t', encoding=encoding, header=0, index_col=0)).T
        df.index.name = None  # Remove index name if it exists
        df.reset_index(inplace=True)  # Reset index to avoid number-based indexing
        df.rename(columns={'index': 'bcr_patient_barcode'}, inplace=True)  # Rename the reset index column
        print(f"Successfully read {file_path}, shape: {df.shape}")

    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return None

    # Add cancer cohort
    df['cancer_cohort'] = cancer_cohort  

    # Identify genes that exist in the file (order-independent)
    available_genes = CGAS_STING_GENES.intersection(df.columns)

    # Select relevant columns (including patient_id and cancer_cohort)
    selected_columns = ['bcr_patient_barcode', 'cancer_cohort'] + list(available_genes)
    df_filtered = df[selected_columns]
    print(f"Filtered relevant columns for {file_path}, new shape: {df_filtered.shape}")
    
    if not available_genes:
        print(f"Skipping {file_path}: None of the cGAS-STING genes are present.")
        return None
    
    return df_filtered

def read_gene_expression():
    """Main function to read and process gene expression data from MiniO."""
    print("Starting gene expression reading process...")
    tsv_files = list_tsv_files()
    if not tsv_files:
        print("No TSV files found in MiniO.")
        return

    all_data = []
    for tsv in tsv_files:
        local_path = f"/tmp/{tsv}"
        cancer_cohort = tsv.replace(".tsv", "")  # Extract cohort name from filename
        download_tsv(tsv, local_path)
        data = process_tsv(local_path, cancer_cohort)
        if data is not None:
            all_data.append(data)

    # Combine all datasets
    if all_data:
        combined_df = pd.concat(all_data, ignore_index=True)
        print("Final processed gene expression dataset:")

    else:
        print("No valid gene expression data found.")
        return None

    return combined_df

#if __name__ == "__main__":
#    read_gene_expression()
