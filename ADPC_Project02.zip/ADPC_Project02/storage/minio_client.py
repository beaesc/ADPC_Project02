from minio import Minio
from minio.error import S3Error
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# MiniO configuration from .env
MINIO_URL = os.getenv("MINIO_URL")
ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY")
SECRET_KEY = os.getenv("MINIO_SECRET_KEY")
BUCKET_NAME = os.getenv("MINIO_BUCKET_NAME")

# Initialize MiniO client
minio_client = Minio(
    MINIO_URL,
    access_key=ACCESS_KEY,
    secret_key=SECRET_KEY,
    secure=False
)

def upload_to_minio(file_path, object_name):
    """Uploads a file to MiniO bucket."""
    try:
        if not minio_client.bucket_exists(BUCKET_NAME):
            minio_client.make_bucket(BUCKET_NAME)
            print(f"Bucket '{BUCKET_NAME}' created.")

        minio_client.fput_object(BUCKET_NAME, object_name, file_path)
        print(f"Uploaded {object_name} to MiniO bucket '{BUCKET_NAME}'")
    except S3Error as e:
        print(f"MiniO error: {e}")

if __name__ == "__main__":
    # Test file upload
    test_file = "./data/sample.tsv"
    if os.path.exists(test_file):
        upload_to_minio(test_file, "sample.tsv")
    else:
        print("No test file found in ./data/sample.tsv")
