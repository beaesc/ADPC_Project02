import os
from scraper.xena_scraper import process_and_upload_tsv
from processing.gene_expression_reader import read_gene_expression
from processing.gene_expression_merger import merge_with_clinical_data

# Define file paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLINICAL_DATA_PATH = os.path.join(BASE_DIR, "TCGA_clinical_survival_data.tsv")
MERGED_DATA_OUTPUT = os.path.join(BASE_DIR, "merged_gene_expression_data.txt")  # ✅ Output file path

def main():
    """Main workflow to scrape, process, and merge gene expression data."""

    print("Step 1: Scraping and uploading gene expression data from Xena Browser...")
    process_and_upload_tsv()  # ✅ Run scraper first

    print("Step 2: Fetching gene expression data from MiniO...")
    gene_expression_df = read_gene_expression()

    if gene_expression_df is None:
        print("No gene expression data found.")
        return

    if not os.path.exists(CLINICAL_DATA_PATH):
        print(f"Error: Clinical survival data file not found at {CLINICAL_DATA_PATH}")
        return

    print("Step 3: Merging with clinical survival data...")
    merged_data = merge_with_clinical_data(gene_expression_df, CLINICAL_DATA_PATH)

    if merged_data is not None and not merged_data.empty:
        print(f"Step 4: Saving merged dataset to {MERGED_DATA_OUTPUT} ...")
        merged_data.to_csv(MERGED_DATA_OUTPUT, sep='\t', index=False) 
        print("Merged data successfully saved!")
    else:
        print("Merging failed. No valid data found.")

if __name__ == "__main__":
    main()